from flask import Flask,render_template,redirect,request
from flask.helpers import url_for
from datetime import *
from flask_sqlalchemy import SQLAlchemy
from pytz import timezone 
from sqlalchemy.orm import defaultload
import psycopg2

app=Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = "postgresql://postgres:gopireddy@localhost/onroad"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config['SECRET_KEY'] = 'thisismykey'
db = SQLAlchemy(app)


#-------------------------------DATABASE CREATION------------------------------------------------
#-------------------------------TABLE CREATION---------------------------------------------------
class Customer(db.Model):
    __tablename__='customer_details'
    customer_id = db.Column(db.Integer,primary_key = True)
    date = db.Column(db.Date,default = date.today(),nullable=False)
    time = db.Column(db.String(10),default = datetime.now(timezone("Asia/Kolkata")).strftime('%H:%M'),nullable=False)
    customer_name = db.Column(db.String(40))
    customer_vehicle_type = db.Column(db.String(30))
    customer_vehicle_problem = db.Column(db.String(45))
    problem_status = db.Column(db.String(20),default='pending',nullable=False)
    customer_number = db.Column(db.String(20))
    vehicle_near_area = db.Column(db.String(40))
    pass


#------------------------------Rountes----------------------------------------------------------------
#-----------------------------------------------------------------------------------------------------

@app.route("/")
@app.route("/home")
def main():
    return render_template("index.html")

@app.route("/twowheeler")
def twowheeler():
    return render_template("two.html")

@app.route("/fuel")
def threewheeler():
    return render_template("three.html")

@app.route("/fourwheeler")
def fourwheeler():
    return render_template("four.html")

@app.route("/<type>/<problem>", methods=["GET"])
def service(type,problem):
    print(type,problem)
    return render_template("contact.html",type=type,problem=problem)

@app.route("/posted", methods=["POST"])
def posted():
    vtype=request.form.get("v-type")
    proble=request.form.get("problem")
    name=request.form.get('name')
    area=request.form.get('area')
    number=request.form.get('number')
    print(name,area,number,vtype,proble)

    pro=Customer(customer_name=name,customer_vehicle_type=vtype,customer_vehicle_problem=proble,customer_number=number,vehicle_near_area=area)
    db.session.add(pro)
    db.session.commit()
    return redirect("/home")

if __name__=='__main__' :
    db.create_all()
    app.run(debug=True)